MISTER CRANK - AMAZON UPLOAD IMAGES
Copies only. The originals stay in "Amazon store images".
All files are PNG and every size has been checked.

1 App listing  (Amazon Developer Console > Mister Crank > Images & Multimedia)
  01-small-icon-114x114.png             Small icon (114x114)
  02-large-icon-512x512.png             Large icon (512x512)
  03-firetv-icon-1280x720.png           Fire TV icon (1280x720)
  04-firetv-background-1920x1080.png    Fire TV background (1920x1080)
  05-promo-image-1024x500.png           Promotional image (1024x500)
  06 to 14  screenshot-1 ... screenshot-9   Screenshots (1920x1080). Upload them in number order.

2 Crank Pass item  (In-App Items > Crank Pass > Images)
  15-crank-pass-large-icon-512x512.png  Large icon (512x512, transparent)
  16-crank-pass-small-icon-114x114.png  Small icon (114x114, transparent)

Inside the VirtualBox VM, download everything from:
  https://perfectjoust.github.io/mister-crank/press-kit/
